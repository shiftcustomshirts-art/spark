import Contact from "./components/Contact";
import Cursor from "./components/Cursor";
import CTASection from "./components/CTASection";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Industries from "./components/Industries";
import Marquee from "./components/Marquee";
import Navbar from "./components/Navbar";
import Process from "./components/Process";
import ScrollProgress from "./components/ScrollProgress";
import Services from "./components/Services";
import Trust from "./components/Trust";
import Why from "./components/Why";
import Work from "./components/Work";
import { ScrollProvider } from "./lib/scroll";
import { useRoute } from "./lib/useRoute";
import Admin from "./pages/Admin";

function Site() {
  return (
    <ScrollProvider>
      <div className="noise relative min-h-screen bg-ink text-white">
        <Cursor />
        <ScrollProgress />
        <Navbar />
        <main>
          <Hero />
          <Marquee />
          <Trust />
          <Services />
          <Process />
          <Industries />
          <Why />
          <Work />
          <CTASection />
          <Contact />
        </main>
        <Footer />
      </div>
    </ScrollProvider>
  );
}

export default function App() {
  const route = useRoute();
  return route === "admin" ? <Admin /> : <Site />;
}
