import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Building2,
  CheckCircle2,
  Clock3,
  Download,
  Inbox,
  LogOut,
  Mail,
  Phone,
  Search,
  Star,
  Tag,
  Trash2,
  TrendingUp,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Logo } from "../components/ui/Logo";
import {
  deleteLead,
  downloadCSV,
  getLeads,
  STATUS_META,
  subscribe,
  timeAgo,
  updateLead,
  type Lead,
  type LeadStatus,
} from "../lib/leads";
import { cn } from "../utils/cn";

const FILTERS: Array<{ key: LeadStatus | "all" | "starred"; label: string }> = [
  { key: "all", label: "All" },
  { key: "new", label: "New" },
  { key: "contacted", label: "Contacted" },
  { key: "won", label: "Clients" },
  { key: "starred", label: "Starred" },
  { key: "archived", label: "Archived" },
];

function StatCard({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: typeof Inbox;
  label: string;
  value: number | string;
  accent: string;
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
      <div className={cn("absolute -right-8 -top-8 size-24 rounded-full blur-2xl", accent)} />
      <div className="relative flex items-center justify-between">
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">{label}</p>
        <Icon className="size-4 text-mist" />
      </div>
      <p className="relative mt-3 font-display text-3xl font-semibold text-white">{value}</p>
    </div>
  );
}

export default function AdminDashboard({ onLogout }: { onLogout: () => void }) {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["key"]>("all");
  const [query, setQuery] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    const sync = () => setLeads(getLeads());
    sync();
    return subscribe(sync);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return leads.filter((l) => {
      const matchFilter =
        filter === "all"
          ? l.status !== "archived"
          : filter === "starred"
            ? l.starred
            : l.status === filter;
      const matchQuery =
        !q ||
        [l.name, l.company, l.email, l.phone, l.topic, l.message]
          .join(" ")
          .toLowerCase()
          .includes(q);
      return matchFilter && matchQuery;
    });
  }, [leads, filter, query]);

  const active = leads.find((l) => l.id === activeId) ?? null;

  const stats = useMemo(
    () => ({
      total: leads.length,
      fresh: leads.filter((l) => l.status === "new").length,
      contacted: leads.filter((l) => l.status === "contacted").length,
      won: leads.filter((l) => l.status === "won").length,
    }),
    [leads]
  );

  return (
    <div className="min-h-screen bg-ink">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-white/[0.07] bg-ink/85 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-between gap-4 px-5 py-4 md:px-8">
          <div className="flex items-center gap-4">
            <Logo />
            <span className="hidden rounded-full border border-volt/30 bg-volt/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-volt sm:inline-block">
              Admin
            </span>
          </div>
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => downloadCSV(leads)}
              disabled={!leads.length}
              className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.03] px-4 py-2.5 text-sm font-medium text-white transition-colors hover:border-volt/50 hover:text-volt disabled:opacity-40"
            >
              <Download className="size-4" />
              <span className="hidden sm:inline">Export CSV</span>
            </button>
            <a
              href="#top"
              onClick={() => {
                window.location.hash = "#top";
              }}
              className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.03] px-4 py-2.5 text-sm font-medium text-mist transition-colors hover:text-white"
            >
              <ArrowLeft className="size-4" />
              <span className="hidden sm:inline">Website</span>
            </a>
            <button
              onClick={onLogout}
              className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.03] px-4 py-2.5 text-sm font-medium text-mist transition-colors hover:border-rose-400/50 hover:text-rose-300"
            >
              <LogOut className="size-4" />
              <span className="hidden sm:inline">Log out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl px-5 py-10 md:px-8">
        <h1 className="font-display text-[clamp(1.9rem,4vw,2.8rem)] font-semibold tracking-tight text-white">
          Client Requests
        </h1>
        <p className="mt-2 text-sm text-mist">
          Every enquiry submitted through the website contact form, in one place.
        </p>

        {/* Stats */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard icon={Inbox} label="Total enquiries" value={stats.total} accent="bg-spark/25" />
          <StatCard icon={Clock3} label="New / unread" value={stats.fresh} accent="bg-volt/25" />
          <StatCard
            icon={CheckCircle2}
            label="Contacted"
            value={stats.contacted}
            accent="bg-pulse/25"
          />
          <StatCard
            icon={TrendingUp}
            label="Converted"
            value={stats.won}
            accent="bg-emerald-400/20"
          />
        </div>

        {/* Controls */}
        <div className="mt-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={cn(
                  "rounded-full border px-4 py-2 text-sm font-medium transition-all duration-300",
                  filter === f.key
                    ? "border-transparent bg-gradient-to-r from-volt via-spark to-pulse text-white shadow-[0_6px_26px_-10px_rgba(94,107,255,0.9)]"
                    : "border-white/10 bg-white/[0.03] text-mist hover:border-white/25 hover:text-white"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="relative lg:w-80">
            <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-mist" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search name, business, email…"
              aria-label="Search enquiries"
              className="w-full rounded-full border border-white/10 bg-white/[0.04] py-3 pl-11 pr-4 text-sm text-white outline-none transition-all placeholder:text-mist/50 focus:border-volt/60"
            />
          </div>
        </div>

        {/* List */}
        <div className="mt-6 overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.015]">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center px-6 py-24 text-center">
              <span className="grid size-16 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-mist">
                <Inbox className="size-7" />
              </span>
              <h2 className="mt-6 font-display text-xl font-semibold text-white">
                {leads.length === 0 ? "No enquiries yet" : "Nothing matches this view"}
              </h2>
              <p className="mt-2 max-w-sm text-sm text-mist">
                {leads.length === 0
                  ? "When someone submits the contact form on your website, their details will appear here automatically."
                  : "Try a different filter or clear your search."}
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-white/[0.06]">
              <AnimatePresence initial={false}>
                {filtered.map((l) => (
                  <motion.li
                    key={l.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    className="group"
                  >
                    <button
                      onClick={() => setActiveId(l.id)}
                      className="flex w-full items-start gap-4 px-5 py-5 text-left transition-colors hover:bg-white/[0.03] md:items-center md:px-7"
                    >
                      <span
                        className={cn(
                          "mt-1.5 size-2 shrink-0 rounded-full md:mt-0",
                          STATUS_META[l.status].dot
                        )}
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                          <p className="font-display text-base font-semibold text-white">
                            {l.name || "Unnamed"}
                          </p>
                          {l.company && (
                            <span className="inline-flex items-center gap-1.5 text-xs text-mist">
                              <Building2 className="size-3.5" />
                              {l.company}
                            </span>
                          )}
                          {l.starred && (
                            <Star className="size-3.5 text-amber-300" fill="currentColor" />
                          )}
                        </div>
                        <p className="mt-1 line-clamp-1 text-sm text-mist">{l.message}</p>
                      </div>
                      <div className="hidden shrink-0 items-center gap-3 lg:flex">
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-mist">
                          <Tag className="size-3" />
                          {l.topic}
                        </span>
                        <span
                          className={cn(
                            "rounded-full border px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]",
                            STATUS_META[l.status].cls
                          )}
                        >
                          {STATUS_META[l.status].label}
                        </span>
                      </div>
                      <span className="shrink-0 text-xs text-mist/70">{timeAgo(l.createdAt)}</span>
                    </button>
                  </motion.li>
                ))}
              </AnimatePresence>
            </ul>
          )}
        </div>
      </main>

      {/* Detail drawer */}
      <AnimatePresence>
        {active && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveId(null)}
              className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
            />
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 260, damping: 32 }}
              className="fixed inset-y-0 right-0 z-50 flex w-full max-w-lg flex-col border-l border-white/10 bg-abyss"
              role="dialog"
              aria-label="Enquiry details"
            >
              <div className="flex items-center justify-between border-b border-white/[0.07] px-6 py-5">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-mist">
                    Enquiry details
                  </p>
                  <h2 className="mt-1 font-display text-xl font-semibold text-white">
                    {active.name || "Unnamed"}
                  </h2>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateLead(active.id, { starred: !active.starred })}
                    aria-label="Star enquiry"
                    className={cn(
                      "grid size-10 place-items-center rounded-full border border-white/10 transition-colors",
                      active.starred ? "text-amber-300" : "text-mist hover:text-white"
                    )}
                  >
                    <Star className="size-4" fill={active.starred ? "currentColor" : "none"} />
                  </button>
                  <button
                    onClick={() => setActiveId(null)}
                    aria-label="Close details"
                    className="grid size-10 place-items-center rounded-full border border-white/10 text-mist transition-colors hover:text-white"
                  >
                    <X className="size-4" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto px-6 py-6">
                <p className="text-xs text-mist">
                  Received {new Date(active.createdAt).toLocaleString()}
                </p>

                {/* Status switcher */}
                <p className="mt-6 text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">
                  Status
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {(Object.keys(STATUS_META) as LeadStatus[]).map((s) => (
                    <button
                      key={s}
                      onClick={() => updateLead(active.id, { status: s })}
                      className={cn(
                        "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-all",
                        active.status === s
                          ? STATUS_META[s].cls
                          : "border-white/10 bg-white/[0.02] text-mist hover:text-white"
                      )}
                    >
                      {STATUS_META[s].label}
                    </button>
                  ))}
                </div>

                {/* Contact details */}
                <div className="mt-7 space-y-px overflow-hidden rounded-2xl border border-white/[0.08]">
                  {[
                    { icon: Building2, label: "Business", value: active.company || "—" },
                    { icon: Mail, label: "Email", value: active.email || "—", href: active.email ? `mailto:${active.email}` : undefined },
                    { icon: Phone, label: "Phone", value: active.phone || "—", href: active.phone ? `tel:${active.phone}` : undefined },
                    { icon: Tag, label: "Needs help with", value: active.topic || "—" },
                  ].map((row) => (
                    <div key={row.label} className="flex items-center gap-4 bg-white/[0.02] px-4 py-3.5">
                      <row.icon className="size-4 shrink-0 text-mist" />
                      <div className="min-w-0">
                        <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-mist/70">
                          {row.label}
                        </p>
                        {row.href ? (
                          <a
                            href={row.href}
                            className="block truncate text-sm font-medium text-volt hover:underline"
                          >
                            {row.value}
                          </a>
                        ) : (
                          <p className="truncate text-sm font-medium text-white/90">{row.value}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Message */}
                <p className="mt-7 text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">
                  About their business
                </p>
                <p className="mt-3 whitespace-pre-wrap rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 text-sm leading-relaxed text-white/85">
                  {active.message || "—"}
                </p>

                {/* Internal notes */}
                <label
                  htmlFor="notes"
                  className="mt-7 block text-[11px] font-semibold uppercase tracking-[0.18em] text-mist"
                >
                  Internal notes
                </label>
                <textarea
                  id="notes"
                  value={active.notes}
                  onChange={(e) => updateLead(active.id, { notes: e.target.value })}
                  rows={4}
                  placeholder="Follow-up plan, quoted price, next steps…"
                  className="mt-3 w-full resize-none rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm text-white outline-none transition-all placeholder:text-mist/50 focus:border-volt/60"
                />
              </div>

              <div className="flex items-center gap-3 border-t border-white/[0.07] px-6 py-5">
                <a
                  href={active.email ? `mailto:${active.email}` : "#"}
                  className="btn-shine inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gradient-to-r from-volt via-spark to-pulse px-6 py-3.5 font-display text-sm font-semibold text-white"
                >
                  <Mail className="size-4" />
                  Reply by email
                </a>
                <button
                  onClick={() => {
                    deleteLead(active.id);
                    setActiveId(null);
                  }}
                  aria-label="Delete enquiry"
                  className="grid size-12 shrink-0 place-items-center rounded-full border border-white/10 text-mist transition-colors hover:border-rose-400/50 hover:text-rose-300"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
