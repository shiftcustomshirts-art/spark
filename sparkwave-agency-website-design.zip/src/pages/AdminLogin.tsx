import { motion } from "framer-motion";
import { ArrowLeft, Eye, EyeOff, Lock, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Logo } from "../components/ui/Logo";

export default function AdminLogin({ onSuccess }: { onSuccess: (remember: boolean) => boolean }) {
  const [value, setValue] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");
  const [shake, setShake] = useState(0);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = onSuccess(remember);
    if (!ok) {
      setError("Incorrect password. Please try again.");
      setShake((s) => s + 1);
      setValue("");
    }
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink px-5 py-16">
      <div className="bg-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_60%_50%_at_50%_45%,black,transparent)]" />
      <div className="pointer-events-none absolute -left-32 top-0 size-[28rem] rounded-full bg-spark/20 blur-[140px]" />
      <div className="pointer-events-none absolute -right-32 bottom-0 size-[26rem] rounded-full bg-pulse/20 blur-[140px]" />

      <motion.div
        key={shake}
        initial={shake ? { x: -10 } : { opacity: 0, y: 30 }}
        animate={shake ? { x: [10, -8, 6, -4, 0] } : { opacity: 1, y: 0 }}
        transition={shake ? { duration: 0.45 } : { duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md"
      >
        <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-tr from-volt/15 via-spark/15 to-pulse/15 blur-2xl" />
        <div className="glass relative rounded-3xl p-8 md:p-10">
          <div className="flex items-center justify-between">
            <Logo />
            <span className="grid size-11 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-volt">
              <ShieldCheck className="size-5" />
            </span>
          </div>

          <h1 className="mt-8 font-display text-3xl font-semibold tracking-tight text-white">
            Admin Access
          </h1>
          <p className="mt-2.5 text-sm leading-relaxed text-mist">
            Enter the admin password to review incoming client requests and enquiry details.
          </p>

          <form onSubmit={submit} className="mt-8">
            <label
              htmlFor="admin-password"
              className="mb-2 block text-[11px] font-semibold uppercase tracking-[0.18em] text-mist"
            >
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-mist" />
              <input
                id="admin-password"
                name="password"
                type={show ? "text" : "password"}
                value={value}
                onChange={(e) => {
                  setValue(e.target.value);
                  setError("");
                }}
                autoFocus
                autoComplete="current-password"
                placeholder="••••••••••"
                className="w-full rounded-xl border border-white/10 bg-white/[0.04] px-11 py-3.5 text-sm text-white outline-none transition-all duration-300 placeholder:text-mist/50 focus:border-volt/60 focus:bg-white/[0.06] focus:shadow-[0_0_0_3px_rgba(58,226,255,0.12)]"
              />
              <button
                type="button"
                onClick={() => setShow(!show)}
                aria-label={show ? "Hide password" : "Show password"}
                className="absolute right-3 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-lg text-mist transition-colors hover:text-white"
              >
                {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 text-sm text-rose-400"
                role="alert"
              >
                {error}
              </motion.p>
            )}

            <label className="mt-5 flex cursor-pointer items-center gap-3 text-sm text-mist">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="size-4 accent-[#5e6bff]"
              />
              Keep me signed in on this device
            </label>

            <button
              type="submit"
              className="btn-shine mt-7 inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-gradient-to-r from-volt via-spark to-pulse bg-[length:180%_100%] bg-left px-8 py-4 font-display text-sm font-semibold tracking-wide text-white shadow-[0_8px_40px_-8px_rgba(94,107,255,0.7)] transition-all duration-500 hover:bg-right"
            >
              Unlock Dashboard
            </button>
          </form>

          <a
            href="#top"
            onClick={() => {
              window.location.hash = "#top";
            }}
            className="mt-7 inline-flex items-center gap-2 text-sm text-mist transition-colors hover:text-white"
          >
            <ArrowLeft className="size-4" />
            Back to website
          </a>
        </div>

        <p className="mt-6 text-center text-xs leading-relaxed text-mist/60">
          Enquiries are stored privately in this browser. For multi-device access, connect a backend
          or CRM later.
        </p>
      </motion.div>
    </main>
  );
}
