import { useCallback, useEffect, useState } from "react";
import AdminDashboard from "./AdminDashboard";
import AdminLogin from "./AdminLogin";

const ADMIN_PASSWORD = "9420525505";
const SESSION_KEY = "sparkwave:admin-auth";

function readAuth(): boolean {
  try {
    return (
      window.sessionStorage.getItem(SESSION_KEY) === "1" ||
      window.localStorage.getItem(SESSION_KEY) === "1"
    );
  } catch {
    return false;
  }
}

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setAuthed(readAuth());
    setReady(true);
  }, []);

  // The login form passes its own value via a hidden form read; we validate here.
  const tryLogin = useCallback((remember: boolean) => {
    const input = document.getElementById("admin-password") as HTMLInputElement | null;
    const ok = input?.value === ADMIN_PASSWORD;
    if (ok) {
      try {
        (remember ? window.localStorage : window.sessionStorage).setItem(SESSION_KEY, "1");
      } catch {
        /* ignore */
      }
      setAuthed(true);
    }
    return ok;
  }, []);

  const logout = useCallback(() => {
    try {
      window.localStorage.removeItem(SESSION_KEY);
      window.sessionStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
    setAuthed(false);
  }, []);

  if (!ready) return <div className="min-h-screen bg-ink" />;

  return authed ? <AdminDashboard onLogout={logout} /> : <AdminLogin onSuccess={tryLogin} />;
}
