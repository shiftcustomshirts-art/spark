import { motion } from "framer-motion";
import { Clock3 } from "lucide-react";
import { Reveal, Stagger, staggerItem } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";
import { cn } from "../utils/cn";

const PROJECTS = [
  {
    img: "/images/work-brand.jpg",
    alt: "Abstract burst of light representing a bold new brand launch",
    category: "Brand Launch",
    title: "Brand Launch",
    desc: "Identity reveals, launch campaigns, and first-impression moments that stick.",
    span: "lg:col-span-4",
    height: "h-80 lg:h-96",
  },
  {
    img: "/images/work-store.jpg",
    alt: "Neon-lit storefront abstract representing local store promotion",
    category: "Store Promotion",
    title: "Store Promotion",
    desc: "Grand openings and local pushes that drive real footfall.",
    span: "lg:col-span-2",
    height: "h-80 lg:h-96",
  },
  {
    img: "/images/work-campaign.jpg",
    alt: "Radiating signal waves representing a digital advertising campaign",
    category: "Digital Campaign",
    title: "Digital Campaign",
    desc: "Multi-channel ad campaigns, planned and optimized to perform.",
    span: "lg:col-span-2",
    height: "h-80",
  },
  {
    img: "/images/work-web.jpg",
    alt: "Floating glass interface panels representing modern website development",
    category: "Website Development",
    title: "Website Development",
    desc: "Fast, modern sites that turn visitors into customers.",
    span: "lg:col-span-2",
    height: "h-80",
  },
  {
    img: "/images/work-startup.jpg",
    alt: "Ascending curve of light representing startup growth momentum",
    category: "Startup Growth",
    title: "Startup Growth",
    desc: "Positioning, strategy, and go-to-market momentum from zero.",
    span: "lg:col-span-2",
    height: "h-80",
  },
];

export default function Work() {
  return (
    <section id="work" className="section-pad relative overflow-hidden">
      <div className="pointer-events-none absolute -right-40 top-1/4 size-[28rem] rounded-full bg-volt/8 blur-[140px]" />

      <div className="relative mx-auto w-full max-w-7xl px-5 md:px-8">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Our work"
            title={
              <>
                Ideas We Turn{" "}
                <span className="font-accent font-normal italic text-gradient">Into Impact.</span>
              </>
            }
          />
          <Reveal delay={0.15}>
            <p className="max-w-sm rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 text-sm leading-relaxed text-mist lg:mb-1">
              We&apos;re a new agency — and honest about it. These placeholders preview the kind of
              work we&apos;re built to deliver.{" "}
              <span className="text-white">Real case studies will live here soon.</span>
            </p>
          </Reveal>
        </div>

        <Stagger className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-6" base={0.09}>
          {PROJECTS.map((p) => (
            <motion.article
              key={p.title}
              variants={staggerItem}
              className={cn(
                "group relative overflow-hidden rounded-3xl border border-white/[0.08] bg-card transition-all duration-500 hover:border-white/[0.2] hover:shadow-[0_30px_80px_-30px_rgba(94,107,255,0.45)] md:col-span-1",
                p.span,
                p.height
              )}
            >
              <img
                src={p.img}
                alt={p.alt}
                loading="lazy"
                width={900}
                height={700}
                className="absolute inset-0 size-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/35 to-transparent transition-opacity duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-volt/0 via-transparent to-transparent opacity-0 transition-opacity duration-700 group-hover:from-spark/25" />

              {/* Coming-soon pill */}
              <span className="glass absolute right-4 top-4 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/85">
                <Clock3 className="size-3 text-volt" />
                Coming soon
              </span>

              <div className="absolute inset-x-0 bottom-0 p-6">
                <span className="inline-block rounded-full border border-volt/30 bg-volt/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-volt">
                  {p.category}
                </span>
                <h3 className="mt-3 font-display text-2xl font-semibold text-white">{p.title}</h3>
                <p className="mt-1.5 max-w-sm text-sm text-mist opacity-0 transition-all duration-500 [transform:translateY(8px)] group-hover:opacity-100 group-hover:[transform:translateY(0)]">
                  {p.desc}
                </p>
              </div>
            </motion.article>
          ))}
        </Stagger>

        <Reveal delay={0.1}>
          <p className="mt-10 text-center text-sm text-mist">
            Your project could be the first story we tell.{" "}
            <a
              href="#contact"
              className="font-display font-semibold text-white underline decoration-volt/60 underline-offset-4 transition-colors hover:text-volt"
            >
              Let&apos;s make it worth talking about.
            </a>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
