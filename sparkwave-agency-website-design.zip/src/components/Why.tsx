import { motion } from "framer-motion";
import { Layers, Lightbulb, Shapes, SlidersHorizontal, TrendingUp } from "lucide-react";
import { Reveal, Stagger, staggerItem } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

const POINTS = [
  {
    icon: SlidersHorizontal,
    title: "Personalized strategies",
    desc: "Built around your business and your market — never recycled from a template.",
  },
  {
    icon: Lightbulb,
    title: "Creative meets strategic",
    desc: "Ideas that look great, sound right, and know exactly what they need to achieve.",
  },
  {
    icon: TrendingUp,
    title: "Focused on growth",
    desc: "Attention is nice. Customers are better. Every move is aimed at both.",
  },
  {
    icon: Layers,
    title: "One agency, everything covered",
    desc: "Marketing, advertising, websites, and consulting — under one roof, in sync.",
  },
  {
    icon: Shapes,
    title: "Flexible for every stage",
    desc: "Solutions that fit where you are today and scale as your business grows.",
  },
];

export default function Why() {
  return (
    <section id="why" className="section-pad relative overflow-hidden bg-abyss">
      <div className="pointer-events-none absolute right-[-10rem] top-10 size-[30rem] rounded-full bg-spark/12 blur-[150px]" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-white/15 to-transparent" />

      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-2 lg:gap-20">
        {/* Visual */}
        <Reveal className="relative order-2 lg:order-1">
          <div className="relative mx-auto max-w-lg">
            <div className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-tr from-pulse/20 via-spark/15 to-volt/20 blur-3xl" />
            <div className="relative overflow-hidden rounded-[2rem] border border-white/10">
              <img
                src="/images/why-visual.jpg"
                alt="Glowing network of connected nodes representing one growth partner uniting marketing, creative, consulting and technology"
                loading="lazy"
                width={900}
                height={900}
                className="aspect-square w-full object-cover transition-transform duration-700 hover:scale-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
              <div className="glass absolute bottom-5 left-5 right-5 rounded-2xl px-5 py-4">
                <p className="font-display text-sm font-semibold text-white">
                  One partner. Every growth lever.
                </p>
                <p className="mt-0.5 text-xs text-mist">
                  Strategy · Creative · Digital · Web · Consulting
                </p>
              </div>
            </div>

            {/* Rotating badge */}
            <div className="glass absolute -right-5 -top-6 hidden size-32 place-items-center rounded-full sm:grid">
              <svg viewBox="0 0 120 120" className="absolute inset-0 size-full animate-spin-slower" aria-hidden>
                <defs>
                  <path id="circlePath" d="M 60,60 m -42,0 a 42,42 0 1,1 84,0 a 42,42 0 1,1 -84,0" />
                </defs>
                <text className="fill-mist" fontSize="10.2" letterSpacing="2.5">
                  <textPath href="#circlePath">SPARKWAVE · GROWTH PARTNER · SPARKWAVE ·</textPath>
                </text>
              </svg>
              <svg viewBox="0 0 24 24" className="size-7 text-volt" fill="currentColor" aria-hidden>
                <path d="M13.4 2 5.6 13.6h4.2L9 22l8.6-11.6h-4.6L13.4 2z" />
              </svg>
            </div>
          </div>
        </Reveal>

        {/* Copy */}
        <div className="order-1 lg:order-2">
          <SectionHeading
            eyebrow="Why Sparkwave"
            title={
              <>
                More Than an Agency.{" "}
                <span className="font-accent font-normal italic text-gradient">
                  Your Growth Partner.
                </span>
              </>
            }
            description="Most vendors sell you a service. We bring marketing, creative execution, business thinking, and technology together — so every piece of your growth engine pulls in the same direction."
          />

          <Stagger className="mt-10 flex flex-col gap-5" base={0.09}>
            {POINTS.map((p) => (
              <motion.div key={p.title} variants={staggerItem} className="group flex items-start gap-4">
                <span className="grid size-11 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-volt transition-all duration-500 group-hover:border-pulse/40 group-hover:text-pulse">
                  <p.icon className="size-5" />
                </span>
                <div>
                  <h3 className="font-display text-base font-semibold text-white">{p.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-mist">{p.desc}</p>
                </div>
              </motion.div>
            ))}
          </Stagger>
        </div>
      </div>
    </section>
  );
}
