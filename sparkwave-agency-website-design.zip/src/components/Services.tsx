import { motion } from "framer-motion";
import { ArrowRight, Compass, Megaphone, MonitorSmartphone, Target } from "lucide-react";
import { useScrollTo } from "../lib/scroll";
import { Stagger, staggerItem } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

const SERVICES = [
  {
    icon: Megaphone,
    title: "Brand Promotion",
    desc: "Get your name out there. We build awareness that sticks — from launch-day buzz to an always-on brand presence.",
    items: [
      "Brand awareness campaigns",
      "Social media promotion",
      "Local business promotion",
      "Launch campaigns",
      "Creative promo strategies",
    ],
    accent: "text-volt",
    glow: "from-volt/25",
    ring: "group-hover:border-volt/40 hover:shadow-[0_30px_80px_-30px_rgba(58,226,255,0.35)]",
  },
  {
    icon: Target,
    title: "Advertising & Campaigns",
    desc: "Campaigns built to perform. We plan, launch, and optimize ads that reach the right people at the right moment.",
    items: [
      "Digital advertising",
      "Social media ads",
      "Shop & store launch campaigns",
      "Customer acquisition",
      "Campaign strategy & optimization",
    ],
    accent: "text-spark",
    glow: "from-spark/25",
    ring: "group-hover:border-spark/40 hover:shadow-[0_30px_80px_-30px_rgba(94,107,255,0.4)]",
  },
  {
    icon: Compass,
    title: "Startup & Business Consulting",
    desc: "Grow with a plan. Practical guidance on positioning, strategy, and the moves that actually matter at your stage.",
    items: [
      "Business growth consulting",
      "Startup guidance",
      "Marketing strategy",
      "Brand positioning",
      "Growth planning",
    ],
    accent: "text-pulse",
    glow: "from-pulse/25",
    ring: "group-hover:border-pulse/40 hover:shadow-[0_30px_80px_-30px_rgba(162,107,255,0.4)]",
  },
  {
    icon: MonitorSmartphone,
    title: "Website Development",
    desc: "Modern, fast, conversion-ready websites. Your best salesperson — working for you around the clock.",
    items: [
      "Business & startup websites",
      "Landing pages",
      "Service websites",
      "Promotional & launch sites",
      "Responsive modern design",
    ],
    accent: "text-volt",
    glow: "from-cyan-400/25",
    ring: "group-hover:border-cyan-300/40 hover:shadow-[0_30px_80px_-30px_rgba(34,211,238,0.35)]",
  },
];

export default function Services() {
  const { go } = useScrollTo();
  return (
    <section id="services" className="section-pad relative overflow-hidden">
      <div className="pointer-events-none absolute left-1/2 top-0 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div className="pointer-events-none absolute -left-52 top-1/3 size-[30rem] rounded-full bg-spark/10 blur-[140px]" />

      <div className="mx-auto w-full max-w-7xl px-5 md:px-8">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="What we do"
            title={
              <>
                Everything You Need to Get Your{" "}
                <span className="font-accent font-normal italic text-gradient">
                  Business Moving.
                </span>
              </>
            }
          />
          <p className="max-w-sm text-base leading-relaxed text-mist lg:pb-2 lg:text-right">
            Four core services. One goal: turning attention into customers, and customers into
            growth.
          </p>
        </div>

        <Stagger className="mt-14 grid gap-6 md:grid-cols-2" base={0.1}>
          {SERVICES.map((s, i) => (
            <motion.article
              key={s.title}
              variants={staggerItem}
              className={`group relative overflow-hidden rounded-3xl border border-white/[0.08] bg-card/80 p-8 transition-all duration-500 hover:-translate-y-1.5 md:p-10 ${s.ring}`}
            >
              {/* Hover glow */}
              <div
                className={`pointer-events-none absolute -right-20 -top-20 size-56 rounded-full bg-gradient-to-br ${s.glow} to-transparent opacity-0 blur-3xl transition-opacity duration-700 group-hover:opacity-100`}
              />
              <span className="pointer-events-none absolute right-7 top-6 font-display text-6xl font-bold leading-none text-white/[0.05] transition-colors duration-500 group-hover:text-white/[0.09]">
                0{i + 1}
              </span>

              <span
                className={`relative grid size-14 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] ${s.accent} transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-105`}
              >
                <s.icon className="size-6" />
              </span>

              <h3 className="relative mt-7 font-display text-2xl font-semibold tracking-tight text-white">
                {s.title}
              </h3>
              <p className="relative mt-3 leading-relaxed text-mist">{s.desc}</p>

              <ul className="relative mt-6 flex flex-wrap gap-2">
                {s.items.map((item) => (
                  <li
                    key={item}
                    className="rounded-full border border-white/[0.09] bg-white/[0.03] px-3.5 py-1.5 text-xs font-medium text-mist transition-colors duration-300 group-hover:border-white/[0.16] group-hover:text-white/85"
                  >
                    {item}
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  go("#contact");
                }}
                className="relative mt-8 inline-flex items-center gap-2 font-display text-sm font-semibold text-white"
              >
                <span className={`border-b border-white/20 pb-0.5 transition-colors duration-300 group-hover:border-current ${s.accent}`}>
                  Learn More
                </span>
                <ArrowRight className={`size-4 ${s.accent} transition-transform duration-300 group-hover:translate-x-1.5`} />
              </a>
            </motion.article>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
