import { Zap } from "lucide-react";
import { cn } from "../utils/cn";

const ITEMS = [
  "Brand Promotion",
  "Digital Advertising",
  "Social Media Marketing",
  "Website Development",
  "Business Consulting",
  "Startup Growth",
  "Creative Campaigns",
];

export default function Marquee({
  className,
  fast = false,
}: {
  className?: string;
  fast?: boolean;
}) {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div
      className={cn(
        "edge-fade-x relative overflow-hidden border-y border-white/[0.06] bg-white/[0.015] py-5",
        className
      )}
      aria-hidden
    >
      <div
        className={cn(
          "flex w-max items-center gap-10 pr-10",
          fast ? "animate-marquee-fast" : "animate-marquee"
        )}
      >
        {row.map((item, i) => (
          <span key={i} className="flex items-center gap-10 whitespace-nowrap">
            <span className="font-display text-sm font-medium uppercase tracking-[0.28em] text-mist">
              {item}
            </span>
            <Zap className="size-3.5 text-spark" fill="currentColor" />
          </span>
        ))}
      </div>
    </div>
  );
}
