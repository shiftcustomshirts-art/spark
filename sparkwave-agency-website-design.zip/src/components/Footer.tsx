import { ArrowUp, Lock, Mail } from "lucide-react";
import { InstagramIcon, LinkedinIcon, TwitterIcon } from "./ui/BrandIcons";
import { useScrollTo } from "../lib/scroll";
import { Logo } from "./ui/Logo";

const NAV = [
  { label: "Home", href: "#top" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#why" },
  { label: "Work", href: "#work" },
  { label: "Contact", href: "#contact" },
];

const SERVICES = [
  "Brand Promotion",
  "Advertising & Campaigns",
  "Business Consulting",
  "Website Development",
];

const SOCIALS = [
  { icon: InstagramIcon, label: "Instagram (placeholder)", href: "#" },
  { icon: LinkedinIcon, label: "LinkedIn (placeholder)", href: "#" },
  { icon: TwitterIcon, label: "X / Twitter (placeholder)", href: "#" },
  { icon: Mail, label: "Email (placeholder)", href: "#" },
];

export default function Footer() {
  const { go } = useScrollTo();

  const onNav = (e: React.MouseEvent, href: string) => {
    if (href.startsWith("#") && href.length > 1) {
      e.preventDefault();
      go(href);
    } else {
      e.preventDefault();
    }
  };

  return (
    <footer className="relative border-t border-white/[0.07] bg-ink">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-spark/50 to-transparent" />

      <div className="mx-auto w-full max-w-7xl px-5 pb-10 pt-16 md:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_0.8fr_0.9fr_auto]">
          {/* Brand */}
          <div className="max-w-sm">
            <a href="#top" onClick={(e) => onNav(e, "#top")} aria-label="Back to top">
              <Logo />
            </a>
            <p className="mt-5 font-accent text-xl italic leading-snug text-white/85">
              Spark attention. Build brands.{" "}
              <span className="text-gradient">Drive growth.</span>
            </p>
            <p className="mt-4 text-sm leading-relaxed text-mist">
              A digital marketing and business growth agency for startups, local businesses, and
              growing brands.
            </p>
            <div className="mt-6 flex gap-3">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  onClick={(e) => onNav(e, s.href)}
                  aria-label={s.label}
                  className="grid size-10 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-mist transition-all duration-300 hover:border-volt/50 hover:text-volt hover:shadow-[0_0_20px_-4px_rgba(58,226,255,0.5)]"
                >
                  <s.icon className="size-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Nav */}
          <nav aria-label="Footer navigation">
            <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-mist/70">
              Menu
            </p>
            <ul className="mt-5 flex flex-col gap-3">
              {NAV.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    onClick={(e) => onNav(e, l.href)}
                    className="text-sm text-mist transition-colors duration-300 hover:text-white"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Services */}
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-mist/70">
              Services
            </p>
            <ul className="mt-5 flex flex-col gap-3">
              {SERVICES.map((s) => (
                <li key={s}>
                  <a
                    href="#services"
                    onClick={(e) => onNav(e, "#services")}
                    className="text-sm text-mist transition-colors duration-300 hover:text-white"
                  >
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Back to top */}
          <div className="flex items-start justify-start lg:justify-end">
            <button
              onClick={() => go("#top")}
              aria-label="Back to top"
              className="group grid size-12 place-items-center rounded-full border border-white/10 bg-white/[0.03] text-mist transition-all duration-300 hover:border-spark/60 hover:text-white hover:shadow-[0_0_26px_-6px_rgba(94,107,255,0.7)]"
            >
              <ArrowUp className="size-5 transition-transform duration-300 group-hover:-translate-y-1" />
            </button>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-white/[0.07] pt-7 text-xs text-mist/70 sm:flex-row">
          <p>© {new Date().getFullYear()} Sparkwave Agency. All rights reserved.</p>
          <div className="flex items-center gap-5">
            <p className="uppercase tracking-[0.2em]">Marketing · Advertising · Consulting · Web</p>
            <a
              href="#/admin"
              onClick={() => {
                window.location.hash = "#/admin";
              }}
              className="inline-flex items-center gap-1.5 text-mist/60 transition-colors hover:text-volt"
            >
              <Lock className="size-3" />
              Admin
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
