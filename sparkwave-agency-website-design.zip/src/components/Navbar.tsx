import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useScrollTo } from "../lib/scroll";
import { cn } from "../utils/cn";
import { Logo } from "./ui/Logo";

const LINKS = [
  { label: "Services", href: "#services" },
  { label: "Process", href: "#process" },
  { label: "Who We Help", href: "#industries" },
  { label: "Work", href: "#work" },
  { label: "About", href: "#why" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { go, stop, start } = useScrollTo();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (open) stop();
    else start();
    return () => start();
  }, [open, stop, start]);

  const nav = (href: string) => {
    setOpen(false);
    // let the menu close before scrolling away
    setTimeout(() => go(href), open ? 250 : 0);
  };

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        className={cn(
          "fixed inset-x-0 top-0 z-[80] transition-all duration-500",
          scrolled
            ? "border-b border-white/[0.06] bg-ink/75 py-3 backdrop-blur-xl"
            : "border-b border-transparent py-5"
        )}
      >
        <nav className="mx-auto flex w-full max-w-7xl items-center justify-between px-5 md:px-8">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              nav("#top");
            }}
            aria-label="Sparkwave Agency — home"
          >
            <Logo />
          </a>

          <ul className="hidden items-center gap-1 lg:flex">
            {LINKS.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={(e) => {
                    e.preventDefault();
                    nav(l.href);
                  }}
                  className="group relative rounded-full px-4 py-2 text-sm font-medium text-mist transition-colors duration-300 hover:text-white"
                >
                  {l.label}
                  <span className="absolute inset-x-4 -bottom-0.5 h-px origin-left scale-x-0 bg-gradient-to-r from-volt to-pulse transition-transform duration-300 group-hover:scale-x-100" />
                </a>
              </li>
            ))}
          </ul>

          <div className="hidden lg:block">
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                nav("#contact");
              }}
              className="btn-shine group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-volt via-spark to-pulse px-5 py-2.5 font-display text-sm font-semibold text-white shadow-[0_6px_30px_-8px_rgba(94,107,255,0.8)] transition-shadow duration-300 hover:shadow-[0_6px_40px_-4px_rgba(94,107,255,1)]"
            >
              Let&apos;s Talk
              <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>

          <button
            onClick={() => setOpen(!open)}
            aria-label={open ? "Close menu" : "Open menu"}
            className="grid size-11 place-items-center rounded-full border border-white/10 bg-white/[0.04] text-white backdrop-blur-md lg:hidden"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </nav>
      </motion.header>

      {/* Mobile overlay */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, clipPath: "circle(0% at 92% 6%)" }}
            animate={{ opacity: 1, clipPath: "circle(140% at 92% 6%)" }}
            exit={{ opacity: 0, clipPath: "circle(0% at 92% 6%)" }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-[70] flex flex-col bg-abyss/95 backdrop-blur-2xl lg:hidden"
          >
            <div className="pointer-events-none absolute -right-24 top-1/3 size-80 rounded-full bg-spark/20 blur-[100px]" />
            <div className="flex flex-1 flex-col justify-center gap-1 px-8 pt-24">
              {[...LINKS, { label: "Contact", href: "#contact" }].map((l, i) => (
                <motion.a
                  key={l.href}
                  href={l.href}
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.15 + i * 0.07, duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                  onClick={(e) => {
                    e.preventDefault();
                    nav(l.href);
                  }}
                  className="group flex items-center justify-between border-b border-white/[0.06] py-4 font-display text-3xl font-semibold text-white/90 transition-colors hover:text-white"
                >
                  {l.label}
                  <ArrowUpRight className="size-6 text-mist opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:text-volt group-hover:opacity-100" />
                </motion.a>
              ))}
            </div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.55 }}
              className="px-8 pb-12"
            >
              <p className="text-xs uppercase tracking-[0.25em] text-mist">Sparkwave Agency</p>
              <p className="mt-2 font-accent text-lg italic text-white/80">
                Spark attention. Build brands. Drive growth.
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
