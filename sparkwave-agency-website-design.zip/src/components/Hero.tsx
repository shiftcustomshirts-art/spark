import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { Check, Megaphone, MousePointerClick, Sparkles, TrendingUp } from "lucide-react";
import { GhostButton, PrimaryButton } from "./ui/Buttons";

const EASE = [0.22, 1, 0.36, 1] as const;

function Chip({
  icon: Icon,
  title,
  sub,
  className,
  delay = "0s",
}: {
  icon: typeof TrendingUp;
  title: string;
  sub: string;
  className?: string;
  delay?: string;
}) {
  return (
    <div
      className={`glass absolute hidden items-center gap-3 rounded-2xl px-4 py-3 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.8)] animate-float sm:flex ${className}`}
      style={{ animationDelay: delay }}
    >
      <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-volt/25 to-pulse/25 text-volt">
        <Icon className="size-5" />
      </span>
      <span>
        <span className="block font-display text-sm font-semibold text-white">{title}</span>
        <span className="block text-xs text-mist">{sub}</span>
      </span>
    </div>
  );
}

const headline = ["Turn", "your", "business", "into", "a"];

export default function Hero() {
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 55, damping: 18 });
  const sy = useSpring(my, { stiffness: 55, damping: 18 });
  const imgX = useTransform(sx, (v) => v * 22);
  const imgY = useTransform(sy, (v) => v * 22);
  const chipX = useTransform(sx, (v) => v * -14);
  const chipY = useTransform(sy, (v) => v * -14);

  const onMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    mx.set(((e.clientX - r.left) / r.width - 0.5) * 2);
    my.set(((e.clientY - r.top) / r.height - 0.5) * 2);
  };

  return (
    <section
      id="top"
      onMouseMove={onMouseMove}
      className="relative overflow-hidden pb-16 pt-32 md:pt-40 lg:pb-24"
    >
      {/* Backdrop */}
      <div className="bg-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_75%_65%_at_50%_35%,black,transparent)]" />
      <div className="pointer-events-none absolute -left-40 top-[-10rem] size-[34rem] rounded-full bg-spark/25 blur-[140px]" />
      <div className="pointer-events-none absolute -right-40 top-1/3 size-[30rem] rounded-full bg-pulse/20 blur-[140px]" />
      <div className="pointer-events-none absolute bottom-[-12rem] left-1/3 size-[28rem] rounded-full bg-volt/10 blur-[140px]" />

      {/* Spark particles */}
      {[
        "left-[12%] top-[30%]",
        "left-[45%] top-[16%]",
        "right-[8%] top-[18%]",
        "left-[30%] bottom-[14%]",
      ].map((pos, i) => (
        <span
          key={i}
          className={`pointer-events-none absolute size-1 rounded-full bg-volt shadow-[0_0_14px_4px_rgba(58,226,255,0.5)] animate-pulse-soft ${pos}`}
          style={{ animationDelay: `${i * 1.1}s` }}
        />
      ))}

      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-16 px-5 md:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
        {/* Copy */}
        <div className="text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: EASE, delay: 0.25 }}
            className="inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-mist backdrop-blur"
          >
            <Sparkles className="size-3.5 text-volt" />
            Digital Marketing &amp; Business Growth Agency
          </motion.div>

          <h1 className="mt-7 font-display text-[clamp(2.6rem,6.2vw,4.9rem)] font-semibold leading-[1.02] tracking-[-0.025em]">
            {headline.map((word, i) => (
              <motion.span
                key={word}
                initial={{ opacity: 0, y: 40, rotateX: 45 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.9, ease: EASE, delay: 0.35 + i * 0.07 }}
                className="mr-[0.28em] inline-block"
              >
                {word}
              </motion.span>
            ))}
            <motion.span
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: EASE, delay: 0.75 }}
              className="inline-block font-accent font-normal italic tracking-normal text-gradient"
            >
              brand people notice.
            </motion.span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: EASE, delay: 0.9 }}
            className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-mist md:text-lg lg:mx-0"
          >
            Sparkwave Agency helps startups, local businesses, and growing brands get noticed,
            attract customers, and grow through strategic marketing, advertising, creative
            campaigns, consulting, and high-converting websites.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: EASE, delay: 1.05 }}
            className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row lg:justify-start"
          >
            <PrimaryButton href="#contact" className="w-full justify-center sm:w-auto">
              Let&apos;s Grow Your Business
            </PrimaryButton>
            <GhostButton href="#services" className="w-full justify-center sm:w-auto">
              Explore Our Services
            </GhostButton>
          </motion.div>

          <motion.ul
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.3 }}
            className="mt-9 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-mist lg:justify-start"
          >
            {["Strategy-first", "Creative-led", "Built for growing businesses"].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <Check className="size-4 text-volt" strokeWidth={3} />
                {t}
              </li>
            ))}
          </motion.ul>
        </div>

        {/* Visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.2, ease: EASE, delay: 0.6 }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          {/* Rotating ring */}
          <svg
            viewBox="0 0 200 200"
            className="pointer-events-none absolute -right-10 -top-12 size-44 text-white/15 animate-spin-slower lg:-right-14"
            aria-hidden
          >
            <circle cx="100" cy="100" r="92" fill="none" stroke="currentColor" strokeDasharray="3 9" />
          </svg>

          <motion.div style={{ x: imgX, y: imgY }} className="relative">
            <div className="absolute -inset-8 rounded-[3rem] bg-gradient-to-tr from-volt/25 via-spark/20 to-pulse/25 blur-3xl" />
            <div className="relative rounded-[2rem] border border-white/10 bg-white/[0.03] p-2 backdrop-blur-sm">
              <img
                src="/images/hero-spark.jpg"
                alt="Abstract stream of glowing digital energy representing brand growth, marketing and advertising momentum"
                width={880}
                height={1080}
                fetchPriority="high"
                className="aspect-[4/4.4] w-full rounded-[1.6rem] object-cover sm:aspect-[4/4.6]"
              />
              {/* Bottom glass bar on image */}
              <div className="glass absolute inset-x-6 bottom-6 flex items-center justify-between rounded-2xl px-5 py-4">
                <div>
                  <p className="font-display text-sm font-semibold text-white">
                    We don&apos;t just promote businesses.
                  </p>
                  <p className="font-accent text-base italic text-volt">We help them grow.</p>
                </div>
                <TrendingUp className="size-6 text-volt" />
              </div>
            </div>
          </motion.div>

          <motion.div style={{ x: chipX, y: chipY }} className="absolute inset-0">
            <Chip
              icon={Megaphone}
              title="Creative Campaigns"
              sub="Made to be remembered"
              className="-left-4 top-8 lg:-left-10"
              delay="0.4s"
            />
            <Chip
              icon={MousePointerClick}
              title="Digital Advertising"
              sub="Reach the right people"
              className="-right-3 top-1/3 lg:-right-8"
              delay="1.6s"
            />
            <Chip
              icon={TrendingUp}
              title="Growth Strategy"
              sub="Built around your goals"
              className="bottom-24 left-6 lg:-left-6"
              delay="2.6s"
            />
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 1 }}
        className="relative mx-auto mt-16 hidden w-full max-w-7xl items-center gap-3 px-8 lg:flex"
      >
        <span className="relative h-10 w-px overflow-hidden bg-white/15">
          <span className="absolute left-0 top-0 h-4 w-px bg-volt animate-scroll-cue" />
        </span>
        <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-mist">
          Scroll to explore
        </span>
      </motion.div>
    </section>
  );
}
