import type { ReactNode } from "react";
import { cn } from "../../utils/cn";
import { Reveal } from "./Reveal";

type Props = {
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  align?: "left" | "center";
  className?: string;
};

export function SectionHeading({ eyebrow, title, description, align = "left", className }: Props) {
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      <Reveal>
        <span
          className={cn(
            "inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5",
            "text-[11px] font-semibold uppercase tracking-[0.22em] text-mist"
          )}
        >
          <span className="size-1.5 rounded-full bg-gradient-to-r from-volt to-pulse shadow-[0_0_12px_2px_rgba(94,107,255,0.8)]" />
          {eyebrow}
        </span>
      </Reveal>
      <Reveal delay={0.08}>
        <h2 className="mt-6 font-display text-[clamp(2.1rem,4.6vw,3.6rem)] font-semibold leading-[1.06] tracking-[-0.02em] text-white">
          {title}
        </h2>
      </Reveal>
      {description && (
        <Reveal delay={0.16}>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-mist md:text-lg">
            {align === "center" ? <span className="mx-auto block">{description}</span> : description}
          </p>
        </Reveal>
      )}
    </div>
  );
}
