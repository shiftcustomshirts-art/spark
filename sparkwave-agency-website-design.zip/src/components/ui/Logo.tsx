import { cn } from "../../utils/cn";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 36 36" fill="none" className={cn("size-9", className)} aria-hidden>
      <defs>
        <linearGradient id="spark-grad" x1="0" y1="0" x2="36" y2="36">
          <stop offset="0" stopColor="#3ae2ff" />
          <stop offset="0.5" stopColor="#5e6bff" />
          <stop offset="1" stopColor="#a26bff" />
        </linearGradient>
      </defs>
      <rect width="36" height="36" rx="10" fill="url(#spark-grad)" />
      <rect width="36" height="36" rx="10" fill="white" opacity="0.06" />
      <path
        d="M19.6 6.5 10 19.4h5.8L14.4 29.5 26 16.6h-6.2l-.2-10.1z"
        fill="#04060c"
      />
    </svg>
  );
}

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark />
      {!compact && (
        <span className="font-display text-lg font-semibold tracking-tight text-white">
          Spark<span className="text-gradient">wave</span>
          <span className="ml-1.5 align-middle text-[9px] font-medium uppercase tracking-[0.3em] text-mist">
            Agency
          </span>
        </span>
      )}
    </span>
  );
}
