import { ArrowRight } from "lucide-react";
import type { ReactNode } from "react";
import { useScrollTo } from "../../lib/scroll";
import { cn } from "../../utils/cn";
import { Magnetic } from "./Magnetic";

type Props = {
  children: ReactNode;
  href?: string;
  className?: string;
  magnetic?: boolean;
};

function useNav(href?: string) {
  const { go } = useScrollTo();
  return (e: React.MouseEvent) => {
    if (href?.startsWith("#")) {
      e.preventDefault();
      go(href);
    }
  };
}

export function PrimaryButton({ children, href = "#contact", className, magnetic = true }: Props) {
  const onClick = useNav(href);
  const btn = (
    <a
      href={href}
      onClick={onClick}
      className={cn(
        "btn-shine group inline-flex items-center gap-2.5 rounded-full px-7 py-4",
        "bg-gradient-to-r from-volt via-spark to-pulse bg-[length:180%_100%] bg-left",
        "font-display text-sm font-semibold tracking-wide text-white",
        "shadow-[0_8px_40px_-8px_rgba(94,107,255,0.7)]",
        "transition-all duration-500 hover:bg-right hover:shadow-[0_8px_50px_-4px_rgba(94,107,255,0.9)]",
        className
      )}
    >
      {children}
      <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1.5" />
    </a>
  );
  return magnetic ? <Magnetic>{btn}</Magnetic> : btn;
}

export function GhostButton({ children, href = "#services", className, magnetic = true }: Props) {
  const onClick = useNav(href);
  const btn = (
    <a
      href={href}
      onClick={onClick}
      className={cn(
        "group inline-flex items-center gap-2.5 rounded-full border border-white/15 px-7 py-4",
        "bg-white/[0.02] font-display text-sm font-semibold tracking-wide text-white",
        "backdrop-blur-sm transition-all duration-400",
        "hover:border-volt/50 hover:bg-white/[0.06] hover:shadow-[0_0_30px_-6px_rgba(58,226,255,0.4)]",
        className
      )}
    >
      {children}
      <ArrowRight className="size-4 text-volt transition-transform duration-300 group-hover:translate-x-1.5" />
    </a>
  );
  return magnetic ? <Magnetic>{btn}</Magnetic> : btn;
}
