import { motion } from "framer-motion";
import { Reveal } from "./ui/Reveal";
import { PrimaryButton } from "./ui/Buttons";

export default function CTASection() {
  return (
    <section className="relative overflow-hidden py-28 md:py-36">
      {/* Glow field */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 size-[44rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-spark/20 blur-[160px]" />
      <div className="pointer-events-none absolute left-[16%] top-[20%] size-56 rounded-full bg-volt/15 blur-[110px]" />
      <div className="pointer-events-none absolute bottom-[16%] right-[14%] size-56 rounded-full bg-pulse/20 blur-[110px]" />

      {/* Giant bolt watermark */}
      <motion.svg
        viewBox="0 0 24 24"
        initial={{ opacity: 0, scale: 0.8, rotate: -8 }}
        whileInView={{ opacity: 0.06, scale: 1, rotate: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
        className="pointer-events-none absolute left-1/2 top-1/2 size-[30rem] -translate-x-1/2 -translate-y-1/2 fill-white md:size-[36rem]"
        aria-hidden
      >
        <path d="M13.4 2 5.6 13.6h4.2L9 22l8.6-11.6h-4.6L13.4 2z" />
      </motion.svg>

      {/* Sparks */}
      {["left-[18%] top-[28%]", "right-[20%] top-[36%]", "left-[30%] bottom-[20%]", "right-[28%] bottom-[30%]"].map(
        (pos, i) => (
          <span
            key={i}
            className={`pointer-events-none absolute size-1.5 rounded-full bg-volt shadow-[0_0_16px_5px_rgba(58,226,255,0.45)] animate-pulse-soft ${pos}`}
            style={{ animationDelay: `${i * 0.9}s` }}
          />
        )
      )}

      <div className="relative mx-auto max-w-4xl px-5 text-center md:px-8">
        <Reveal>
          <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-mist">
            Your move
          </p>
        </Reveal>
        <Reveal delay={0.08}>
          <h2 className="mt-5 font-display text-[clamp(2.6rem,6.5vw,5rem)] font-semibold leading-[1.03] tracking-[-0.025em] text-white">
            Ready to Make{" "}
            <span className="font-accent font-normal italic text-gradient">Some Noise?</span>
          </h2>
        </Reveal>
        <Reveal delay={0.16}>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-mist md:text-lg">
            Whether you&apos;re launching a new business, opening a new store, or ready to take your
            existing brand to the next level — let&apos;s build your growth strategy together.
          </p>
        </Reveal>
        <Reveal delay={0.24}>
          <div className="mt-10">
            <PrimaryButton href="#contact" className="px-9 py-4.5 text-base">
              Start a Conversation
            </PrimaryButton>
          </div>
        </Reveal>
        <Reveal delay={0.3}>
          <p className="mt-6 text-xs uppercase tracking-[0.25em] text-mist/70">
            No pressure · No jargon · Just a real conversation
          </p>
        </Reveal>
      </div>
    </section>
  );
}
