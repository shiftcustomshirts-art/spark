import { AnimatePresence, motion } from "framer-motion";
import {
  CheckCircle2,
  ChevronDown,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import { InstagramIcon, LinkedinIcon } from "./ui/BrandIcons";
import { useState } from "react";
import { addLead } from "../lib/leads";
import { Reveal } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

const CONTACT_ROWS = [
  { icon: Mail, label: "Email", value: "[your email]" },
  { icon: Phone, label: "Phone", value: "[your phone]" },
  { icon: InstagramIcon, label: "Instagram", value: "[Instagram link]" },
  { icon: LinkedinIcon, label: "LinkedIn", value: "[LinkedIn link]" },
  { icon: MapPin, label: "Location", value: "[Your City, Country]" },
];

const inputCls =
  "w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-sm text-white placeholder:text-mist/50 outline-none transition-all duration-300 focus:border-volt/60 focus:bg-white/[0.06] focus:shadow-[0_0_0_3px_rgba(58,226,255,0.12)]";

const labelCls = "mb-2 block text-[11px] font-semibold uppercase tracking-[0.18em] text-mist";

export default function Contact() {
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [senderName, setSenderName] = useState("");

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const get = (k: string) => String(data.get(k) || "").trim();
    setSenderName(get("name"));
    setStatus("sending");

    addLead({
      name: get("name"),
      company: get("company"),
      email: get("email"),
      phone: get("phone"),
      topic: get("topic"),
      message: get("message"),
    });

    setTimeout(() => setStatus("sent"), 900);
  };

  return (
    <section id="contact" className="section-pad relative overflow-hidden bg-abyss">
      <div className="pointer-events-none absolute left-1/2 top-0 h-px w-2/3 -translate-x-1/2 bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div className="pointer-events-none absolute -left-40 bottom-0 size-[26rem] rounded-full bg-spark/12 blur-[140px]" />

      <div className="relative mx-auto grid w-full max-w-7xl gap-14 px-5 md:px-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
        {/* Info */}
        <div>
          <SectionHeading
            eyebrow="Get in touch"
            title={
              <>
                Let&apos;s Build Your{" "}
                <span className="font-accent font-normal italic text-gradient">Growth Story.</span>
              </>
            }
            description="Tell us where your business is and where you want it to go. We'll come back with ideas, honest advice, and a clear next step."
          />

          <ul className="mt-10 flex flex-col divide-y divide-white/[0.07] rounded-2xl border border-white/[0.08] bg-white/[0.02]">
            {CONTACT_ROWS.map((row) => (
              <li key={row.label} className="group flex items-center gap-4 px-5 py-4 transition-colors duration-300 hover:bg-white/[0.03]">
                <span className="grid size-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-card text-mist transition-colors duration-300 group-hover:text-volt">
                  <row.icon className="size-4.5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-mist/70">
                    {row.label}
                  </p>
                  <p className="truncate text-sm font-medium text-white/90">{row.value}</p>
                </div>
              </li>
            ))}
          </ul>

          <Reveal delay={0.1}>
            <p className="mt-6 text-xs leading-relaxed text-mist/70">
              Replace the placeholders above with your real contact details when you&apos;re ready
              to launch.
            </p>
          </Reveal>
        </div>

        {/* Form */}
        <Reveal delay={0.1} className="relative">
          <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-tr from-volt/10 via-spark/10 to-pulse/10 blur-2xl" />
          <div className="glass relative overflow-hidden rounded-3xl p-7 md:p-9">
            <AnimatePresence mode="wait">
              {status === "sent" ? (
                <motion.div
                  key="sent"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="flex min-h-[28rem] flex-col items-center justify-center text-center"
                >
                  <span className="grid size-16 place-items-center rounded-full bg-gradient-to-br from-volt/20 to-pulse/20">
                    <CheckCircle2 className="size-8 text-volt" />
                  </span>
                  <h3 className="mt-6 font-display text-2xl font-semibold text-white">
                    Thanks{senderName ? `, ${senderName}` : ""} — message received.
                  </h3>
                  <p className="mt-3 max-w-sm text-sm leading-relaxed text-mist">
                    We&apos;ll get back to you shortly with ideas and next steps. Talk soon.
                  </p>
                  <button
                    onClick={() => setStatus("idle")}
                    className="mt-8 rounded-full border border-white/15 px-6 py-3 font-display text-sm font-semibold text-white transition-colors hover:border-volt/50 hover:text-volt"
                  >
                    Send another message
                  </button>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, y: -12 }}
                  onSubmit={onSubmit}
                  className="grid gap-5 sm:grid-cols-2"
                  aria-label="Contact form"
                >
                  <div>
                    <label htmlFor="name" className={labelCls}>
                      Name *
                    </label>
                    <input id="name" name="name" required placeholder="Your name" className={inputCls} autoComplete="name" />
                  </div>
                  <div>
                    <label htmlFor="company" className={labelCls}>
                      Business / Company Name
                    </label>
                    <input id="company" name="company" placeholder="Your business" className={inputCls} autoComplete="organization" />
                  </div>
                  <div>
                    <label htmlFor="email" className={labelCls}>
                      Email *
                    </label>
                    <input id="email" name="email" type="email" required placeholder="you@business.com" className={inputCls} autoComplete="email" />
                  </div>
                  <div>
                    <label htmlFor="phone" className={labelCls}>
                      Phone Number
                    </label>
                    <input id="phone" name="phone" type="tel" placeholder="+00 0000 000 000" className={inputCls} autoComplete="tel" />
                  </div>
                  <div className="relative sm:col-span-2">
                    <label htmlFor="topic" className={labelCls}>
                      What do you need help with?
                    </label>
                    <select id="topic" name="topic" className={`${inputCls} appearance-none pr-10 [&>option]:bg-card`} defaultValue="Brand Promotion">
                      <option>Brand Promotion</option>
                      <option>Advertising &amp; Campaigns</option>
                      <option>Business / Startup Consulting</option>
                      <option>Website Development</option>
                      <option>A bit of everything</option>
                      <option>Not sure yet — help me decide</option>
                    </select>
                    <ChevronDown className="pointer-events-none absolute bottom-4 right-4 size-4 text-mist" />
                  </div>
                  <div className="sm:col-span-2">
                    <label htmlFor="message" className={labelCls}>
                      Tell us about your business *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={4}
                      placeholder="What do you do, who are your customers, and what are you trying to achieve?"
                      className={`${inputCls} resize-none`}
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <button
                      type="submit"
                      disabled={status === "sending"}
                      className="btn-shine group inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-gradient-to-r from-volt via-spark to-pulse bg-[length:180%_100%] bg-left px-8 py-4 font-display text-sm font-semibold tracking-wide text-white shadow-[0_8px_40px_-8px_rgba(94,107,255,0.7)] transition-all duration-500 hover:bg-right hover:shadow-[0_8px_50px_-4px_rgba(94,107,255,0.95)] disabled:opacity-70 sm:w-auto"
                    >
                      {status === "sending" ? "Sending…" : "Let's Talk"}
                      <Send className="size-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-0.5" />
                    </button>
                    <p className="mt-4 text-xs text-mist/70">
                      We usually reply within one business day.
                    </p>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
