import { motion } from "framer-motion";
import { Map, Rocket, Search, Sparkles } from "lucide-react";
import { Stagger, staggerItem } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

const STEPS = [
  {
    num: "01",
    icon: Search,
    title: "Discover",
    desc: "Understand your business, audience, goals, and challenges.",
  },
  {
    num: "02",
    icon: Map,
    title: "Strategize",
    desc: "Build a customized marketing and growth strategy.",
  },
  {
    num: "03",
    icon: Sparkles,
    title: "Create",
    desc: "Develop campaigns, content, advertisements, websites, and brand experiences.",
  },
  {
    num: "04",
    icon: Rocket,
    title: "Grow",
    desc: "Launch, measure, optimize, and continuously improve.",
  },
];

export default function Process() {
  return (
    <section id="process" className="section-pad relative overflow-hidden bg-abyss">
      <div className="bg-grid pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_40%,black,transparent)]" />
      <div className="pointer-events-none absolute -right-40 bottom-0 size-[26rem] rounded-full bg-pulse/15 blur-[130px]" />

      <div className="relative mx-auto w-full max-w-7xl px-5 md:px-8">
        <SectionHeading
          align="center"
          eyebrow="How we work"
          title={
            <>
              A Simple Process.{" "}
              <span className="font-accent font-normal italic text-gradient">Serious Momentum.</span>
            </>
          }
          description="No chaos, no guesswork. A clear path from first conversation to continuous growth."
        />

        <div className="relative mt-16">
          {/* Connecting line (desktop) */}
          <div className="absolute left-0 right-0 top-[26px] hidden h-px bg-gradient-to-r from-transparent via-white/15 to-transparent lg:block" />

          <Stagger className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8" base={0.12}>
            {STEPS.map((step) => (
              <motion.div key={step.num} variants={staggerItem} className="group relative">
                {/* Node on the line */}
                <div className="relative hidden h-[52px] items-center lg:flex">
                  <span className="relative grid size-[52px] place-items-center rounded-full border border-white/10 bg-card transition-all duration-500 group-hover:border-volt/50 group-hover:shadow-[0_0_30px_-4px_rgba(58,226,255,0.5)]">
                    <step.icon className="size-5 text-volt" />
                    <span className="absolute inset-0 rounded-full border border-volt/0 transition-all duration-500 group-hover:animate-ping group-hover:border-volt/30" />
                  </span>
                </div>

                {/* Mobile icon */}
                <span className="mb-5 grid size-12 place-items-center rounded-2xl border border-white/10 bg-card text-volt lg:hidden">
                  <step.icon className="size-5" />
                </span>

                <span className="block font-display text-[3.4rem] font-bold leading-none tracking-tight text-white/[0.07] transition-colors duration-500 group-hover:text-volt/25 lg:mt-8">
                  {step.num}
                </span>

                <h3 className="mt-3 flex items-center gap-3 font-display text-2xl font-semibold text-white">
                  {step.title}
                </h3>
                <p className="mt-3 max-w-xs leading-relaxed text-mist">{step.desc}</p>

                <span className="mt-5 block h-px w-10 bg-gradient-to-r from-volt to-pulse transition-all duration-500 group-hover:w-20" />
              </motion.div>
            ))}
          </Stagger>
        </div>
      </div>
    </section>
  );
}
