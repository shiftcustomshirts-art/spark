import { motion } from "framer-motion";
import {
  ArrowUpRight,
  MapPin,
  Rocket,
  Star,
  Store,
  TrendingUp,
  UtensilsCrossed,
} from "lucide-react";
import { Reveal, Stagger, staggerItem } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";

const AUDIENCES = [
  {
    icon: Rocket,
    title: "Startups",
    desc: "Launch with clarity, positioning, and momentum from day one.",
  },
  {
    icon: Store,
    title: "New Shops & Stores",
    desc: "Grand-opening buzz that turns into steady local footfall.",
  },
  {
    icon: MapPin,
    title: "Local Businesses",
    desc: "Become the name your neighborhood knows and recommends.",
  },
  {
    icon: UtensilsCrossed,
    title: "Restaurants & Cafés",
    desc: "Turn scrolls and searches into reservations and regulars.",
  },
  {
    icon: Star,
    title: "Personal Brands",
    desc: "Build an audience that trusts your voice and buys your vision.",
  },
  {
    icon: TrendingUp,
    title: "Growing Companies",
    desc: "Scale what already works with sharper systems and strategy.",
  },
];

export default function Industries() {
  return (
    <section id="industries" className="section-pad relative overflow-hidden">
      <div className="pointer-events-none absolute left-[-12rem] top-0 size-[28rem] rounded-full bg-volt/10 blur-[140px]" />

      <div className="relative mx-auto w-full max-w-7xl px-5 md:px-8">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Who we help"
            title={
              <>
                Big Ambitions{" "}
                <span className="font-accent font-normal italic text-gradient">Start Small.</span>
              </>
            }
          />
          <Reveal delay={0.15}>
            <p className="max-w-sm text-base leading-relaxed text-mist lg:pb-2 lg:text-right">
              We work with people building something real — new brands, local favorites, and
              businesses ready for their next chapter.
            </p>
          </Reveal>
        </div>

        <Stagger className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3" base={0.08}>
          {AUDIENCES.map((a) => (
            <motion.div
              key={a.title}
              variants={staggerItem}
              className="group relative overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.02] p-7 transition-all duration-500 hover:-translate-y-1 hover:border-spark/35 hover:bg-white/[0.045] hover:shadow-[0_24px_60px_-24px_rgba(94,107,255,0.4)]"
            >
              <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-volt/0 to-transparent transition-all duration-500 group-hover:via-volt/60" />
              <div className="flex items-start justify-between">
                <span className="grid size-12 place-items-center rounded-xl border border-white/10 bg-card text-mist transition-all duration-500 group-hover:border-volt/40 group-hover:text-volt">
                  <a.icon className="size-5" />
                </span>
                <ArrowUpRight className="size-4 text-mist/40 transition-all duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-volt" />
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold text-white">{a.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-mist">{a.desc}</p>
            </motion.div>
          ))}
        </Stagger>

        <Reveal delay={0.1}>
          <p className="mt-10 text-center text-sm text-mist">
            Launching something else entirely?{" "}
            <span className="font-accent text-base italic text-volt">
              If you&apos;re building, we&apos;re interested.
            </span>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
