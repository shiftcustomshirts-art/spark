import { ArrowUpRight, Compass, PenTool, TrendingUp, Briefcase } from "lucide-react";
import { motion } from "framer-motion";
import { Reveal, Stagger, staggerItem } from "./ui/Reveal";
import { SectionHeading } from "./ui/SectionHeading";
import { useScrollTo } from "../lib/scroll";

const BENEFITS = [
  {
    icon: Compass,
    title: "Strategic Thinking",
    desc: "Every campaign starts with a clear plan — who you're reaching, what you're saying, and why it moves the business forward.",
  },
  {
    icon: PenTool,
    title: "Creative Campaigns",
    desc: "Ideas, visuals, and messaging that make people stop scrolling, pay attention, and remember your name.",
  },
  {
    icon: TrendingUp,
    title: "Digital Growth",
    desc: "Modern channels, sharp targeting, and continuous optimization that turn attention into real customers.",
  },
  {
    icon: Briefcase,
    title: "Business-Focused Solutions",
    desc: "Marketing shaped around your budget, your stage, and your goals — practical, honest, and built to be used.",
  },
];

export default function Trust() {
  const { go } = useScrollTo();
  return (
    <section id="about" className="section-pad relative">
      <div className="mx-auto grid w-full max-w-7xl gap-14 px-5 md:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-20">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <SectionHeading
            eyebrow="Why businesses choose us"
            title={
              <>
                From New Idea to{" "}
                <span className="font-accent font-normal italic text-gradient">Growing Brand.</span>
              </>
            }
            description="Starting is hard. Getting noticed is harder. Sparkwave gives new and growing businesses the strategy, creativity, and digital firepower usually reserved for the big players — without the big-agency baggage."
          />
          <Reveal delay={0.2}>
            <a
              href="#why"
              onClick={(e) => {
                e.preventDefault();
                go("#why");
              }}
              className="group mt-8 inline-flex items-center gap-2 font-display text-sm font-semibold text-white"
            >
              <span className="border-b border-volt/50 pb-0.5 transition-colors group-hover:border-volt group-hover:text-volt">
                What makes us different
              </span>
              <ArrowUpRight className="size-4 text-volt transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
            </a>
          </Reveal>
        </div>

        <Stagger className="flex flex-col">
          {BENEFITS.map((b, i) => (
            <motion.div
              key={b.title}
              variants={staggerItem}
              className="group relative border-t border-white/[0.08] py-8 transition-colors duration-500 last:border-b hover:border-white/[0.18] md:py-9"
            >
              <div className="flex items-start gap-6">
                <span className="pt-1 font-display text-sm font-medium tracking-widest text-mist/60">
                  0{i + 1}
                </span>
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-volt transition-all duration-500 group-hover:border-volt/40 group-hover:bg-volt/10 group-hover:shadow-[0_0_26px_-6px_rgba(58,226,255,0.55)]">
                  <b.icon className="size-5" />
                </span>
                <div>
                  <h3 className="font-display text-xl font-semibold text-white transition-colors duration-300 group-hover:text-volt md:text-2xl">
                    {b.title}
                  </h3>
                  <p className="mt-2 max-w-md leading-relaxed text-mist">{b.desc}</p>
                </div>
              </div>
              <span className="pointer-events-none absolute right-0 top-1/2 hidden h-12 w-px -translate-y-1/2 bg-gradient-to-b from-transparent via-volt/60 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100 md:block" />
            </motion.div>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
