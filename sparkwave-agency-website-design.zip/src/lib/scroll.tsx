import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  type ReactNode,
} from "react";
import Lenis from "lenis";

type ScrollCtx = {
  go: (href: string) => void;
  stop: () => void;
  start: () => void;
};

const Ctx = createContext<ScrollCtx>({
  go: () => {},
  stop: () => {},
  start: () => {},
});

export const useScrollTo = () => useContext(Ctx);

export function ScrollProvider({ children }: { children: ReactNode }) {
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.15,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      touchMultiplier: 1.4,
    });
    lenisRef.current = lenis;

    let raf = 0;
    const loop = (time: number) => {
      lenis.raf(time);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  const go = useCallback((href: string) => {
    const target = document.querySelector(href);
    if (!target) return;
    if (lenisRef.current) {
      lenisRef.current.scrollTo(target as HTMLElement, {
        offset: -76,
        duration: 1.4,
      });
    } else {
      (target as HTMLElement).scrollIntoView({ behavior: "smooth" });
    }
  }, []);

  const stop = useCallback(() => lenisRef.current?.stop(), []);
  const start = useCallback(() => lenisRef.current?.start(), []);

  return <Ctx.Provider value={{ go, stop, start }}>{children}</Ctx.Provider>;
}
