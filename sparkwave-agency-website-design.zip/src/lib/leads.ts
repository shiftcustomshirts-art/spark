export type LeadStatus = "new" | "contacted" | "won" | "archived";

export type Lead = {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  topic: string;
  message: string;
  status: LeadStatus;
  starred: boolean;
  notes: string;
  createdAt: string; // ISO
};

const KEY = "sparkwave:leads";
const EVT = "sparkwave:leads-changed";

export const STATUS_META: Record<LeadStatus, { label: string; cls: string; dot: string }> = {
  new: {
    label: "New",
    cls: "border-volt/40 bg-volt/10 text-volt",
    dot: "bg-volt",
  },
  contacted: {
    label: "Contacted",
    cls: "border-spark/40 bg-spark/10 text-spark",
    dot: "bg-spark",
  },
  won: {
    label: "Client",
    cls: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300",
    dot: "bg-emerald-400",
  },
  archived: {
    label: "Archived",
    cls: "border-white/15 bg-white/5 text-mist",
    dot: "bg-mist",
  },
};

function read(): Lead[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as Lead[]) : [];
  } catch {
    return [];
  }
}

function write(leads: Lead[]) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(leads));
  } catch {
    /* storage unavailable — ignore */
  }
  window.dispatchEvent(new Event(EVT));
}

export function getLeads(): Lead[] {
  return read().sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
}

export function addLead(
  input: Omit<Lead, "id" | "status" | "starred" | "notes" | "createdAt">
): Lead {
  const lead: Lead = {
    ...input,
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `ld_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    status: "new",
    starred: false,
    notes: "",
    createdAt: new Date().toISOString(),
  };
  write([lead, ...read()]);
  return lead;
}

export function updateLead(id: string, patch: Partial<Lead>) {
  write(read().map((l) => (l.id === id ? { ...l, ...patch } : l)));
}

export function deleteLead(id: string) {
  write(read().filter((l) => l.id !== id));
}

export function clearLeads() {
  write([]);
}

export function subscribe(cb: () => void) {
  const handler = () => cb();
  window.addEventListener(EVT, handler);
  window.addEventListener("storage", handler);
  return () => {
    window.removeEventListener(EVT, handler);
    window.removeEventListener("storage", handler);
  };
}

export function toCSV(leads: Lead[]): string {
  const headers = [
    "Date",
    "Name",
    "Business",
    "Email",
    "Phone",
    "Needs help with",
    "Status",
    "Message",
    "Notes",
  ];
  const esc = (v: string) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const rows = leads.map((l) =>
    [
      new Date(l.createdAt).toLocaleString(),
      l.name,
      l.company,
      l.email,
      l.phone,
      l.topic,
      STATUS_META[l.status].label,
      l.message,
      l.notes,
    ]
      .map(esc)
      .join(",")
  );
  return [headers.map(esc).join(","), ...rows].join("\n");
}

export function downloadCSV(leads: Lead[]) {
  const blob = new Blob([toCSV(leads)], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `sparkwave-leads-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - +new Date(iso);
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}
