import { useEffect, useState } from "react";

export type Route = "site" | "admin";

function resolve(): Route {
  if (typeof window === "undefined") return "site";
  const hash = window.location.hash.toLowerCase();
  const path = window.location.pathname.toLowerCase();
  return hash.startsWith("#/admin") || path.endsWith("/admin") ? "admin" : "site";
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(resolve);

  useEffect(() => {
    const onChange = () => setRoute(resolve());
    window.addEventListener("hashchange", onChange);
    window.addEventListener("popstate", onChange);
    return () => {
      window.removeEventListener("hashchange", onChange);
      window.removeEventListener("popstate", onChange);
    };
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [route]);

  return route;
}
